# Runner v0.7.17 eye-test correction

The v0.7.16 released package was reopened by direct runtime review. Automated
acceptance did not overrule the visible failures.

## Physical feet

Bipedal presets now use one short physical support stub per leg. A side-view
boot sprite is anchored to the stub but is not collision geometry. This avoids
the old heel/ball/toe triangle bridging and snagging across SandHybrid cells.

## Gait truth

Walk qualification requires sustained distance, fresh stage work, repeated
alternating cycles, and signed leg crossing. A widened lateral stance or
forward motion without sagittal crossing is reported as crab walking and cannot
become a champion, imitation source, evolved-rig seed, or PIP-valid result.

## Quadruped press

Horizontal body plans receive a shallower, slower press target. Four-chain
compression and authored-pose extension are bounded, and recovery must be held
stably after retraction before the stage can complete.

## Optional art history

The v0.7.17 concept-sheet derivatives were superseded in v0.7.29. The old packaged source references and provenance bundle are removed. The current package contains eight purpose-built side-view runtime sprites with explicit keyed transparency, authored-segment placement, and per-part procedural fallback. Optional art remains independently toggleable and cannot change physics or training.
