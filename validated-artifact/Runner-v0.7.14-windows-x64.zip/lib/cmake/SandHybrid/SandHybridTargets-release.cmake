#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SandHybrid::SandHybrid" for configuration "Release"
set_property(TARGET SandHybrid::SandHybrid APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SandHybrid::SandHybrid PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/SandHybrid.lib"
  )

list(APPEND _cmake_import_check_targets SandHybrid::SandHybrid )
list(APPEND _cmake_import_check_files_for_SandHybrid::SandHybrid "${_IMPORT_PREFIX}/lib/SandHybrid.lib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
